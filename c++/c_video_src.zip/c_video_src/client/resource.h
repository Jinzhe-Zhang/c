//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by BRAnyChatSDKDemo.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_BRANYCHATSDKDEMO_DIALOG     102
#define IDR_MAINFRAME                   128
#define IDC_BUTTON_INIT                 1000
#define IDC_EDIT_LOG                    1001
#define IDC_BUTTON_LEAVEROOM            1002
#define IDC_BUTTON_ENTERROOM            1003
#define IDC_BUTTON_OPENVIDEO            1004
#define IDC_BUTTON_CLOSEVIDEO           1005
#define IDC_BUTTON_VIDEOPROPERTY        1006
#define IDC_COMBO_CAPTURE               1007
#define IDC_COMBO_VCAPTURE              1007
#define IDC_BUTTON_REFRESHCAPTURE       1008
#define IDC_SLIDER_OUTVOLUME            1009
#define IDC_SLIDER_INVOLUME             1010
#define IDC_COMBO_ACAPTURE              1011
#define IDC_BUTTON_AUTOTEST             1012
#define IDC_STATIC_TESTTIMES            1013
#define IDC_BUTTON_STOPTEST             1014
#define IDC_BUTTON_SENDFILE             1015
#define IDC_BUTTON_CLOSEAUDIO           1016
#define IDC_CHECK_VAD                   1017
#define IDC_CHECK_AGC                   1018
#define IDC_CHECK_ECHO                  1019
#define IDC_CHECK_NS                    1020
#define IDC_STATIC_FILESTATUS           1021
#define IDC_BUTTON_TRANSBUF             1022
#define IDC_IPADDRESS_SERVER            1023
#define IDC_EDIT_PORT                   1024
#define IDC_BUTTON_RELEASE              1025
#define IDC_BUTTON_RECORD               1026
#define IDC_PROGRESS_SPEAKVOLUME0       1028
#define IDC_STATIC_USER0                1029
#define IDC_STATIC_USER1                1030
#define IDC_STATIC_USER2                1031
#define IDC_STATIC_USER3                1032
#define IDC_PROGRESS_SPEAKVOLUME1       1033
#define IDC_PROGRESS_SPEAKVOLUME2       1034
#define IDC_PROGRESS_SPEAKVOLUME3       1035
#define IDC_BUTTON_VIDEOCTRL0           1036
#define IDC_STATIC_RECORDSTATE0         1037
#define IDC_STATIC_RECORDSTATE1         1038
#define IDC_STATIC_RECORDSTATE2         1039
#define IDC_STATIC_RECORDSTATE3         1040
#define IDC_BUTTON_AUDIOCTRL0           1041
#define IDC_BUTTON_RECORDCTRL0          1042
#define IDC_BUTTON_SNAPSHOTCTRL0        1043
#define IDC_BUTTON_VIDEOCTRL1           1044
#define IDC_BUTTON_AUDIOCTRL1           1045
#define IDC_BUTTON_RECORDCTRL1          1046
#define IDC_BUTTON_SNAPSHOTCTRL1        1047
#define IDC_BUTTON_VIDEOCTRL2           1048
#define IDC_BUTTON_AUDIOCTRL2           1049
#define IDC_BUTTON_RECORDCTRL2          1050
#define IDC_BUTTON_SNAPSHOTCTRL2        1051
#define IDC_BUTTON_VIDEOCTRL3           1052
#define IDC_BUTTON_AUDIOCTRL3           1053
#define IDC_BUTTON_RECORDCTRL3          1054
#define IDC_BUTTON_SNAPSHOTCTRL3        1055
#define IDC_EDIT_USERNAME               1056
#define IDC_EDIT_LOGINPASS              1057
#define IDC_EDIT_ROOMID                 1058
#define IDC_BUTTON_LOGIN                1059
#define IDC_BUTTON_LOGOUT               1060
#define IDC_EDIT1                       1061

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1062
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
